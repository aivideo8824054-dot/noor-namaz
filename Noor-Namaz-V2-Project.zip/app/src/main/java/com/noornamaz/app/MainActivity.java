package com.noornamaz.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Context;
import android.os.Vibrator;
import android.os.Build;
import android.os.VibrationEffect;
import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.webkit.JavascriptInterface;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.addJavascriptInterface(new Bridge(), "NoorNative");
    web.setWebChromeClient(new WebChromeClient());
    web.loadUrl("file:///android_asset/index.html");
    setContentView(web);
  }
  class Bridge {
    @JavascriptInterface public void vibrate() {
      Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
      if(v!=null && v.hasVibrator()) {
        if(Build.VERSION.SDK_INT>=26) v.vibrate(VibrationEffect.createOneShot(45,VibrationEffect.DEFAULT_AMPLITUDE));
        else v.vibrate(45);
      }
    }
    @JavascriptInterface public String appVersion(){ return "2.0"; }
  }
}
