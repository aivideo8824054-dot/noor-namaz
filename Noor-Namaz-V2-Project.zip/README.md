# Noor Namaz V2
Starter Android WebView project. Includes a functional Tasbih counter with vibration, basic wealth 2.5% estimate, manual/GPS coordinates, and an approximate solar-time display.

Important limitations: prayer calculations are simplified estimates and are NOT verified religious timetables; city-name geocoding, verified Hijri calendar, actual Qibla compass bearing/sensor, complete translations, authentic dua references/audio, full Ramadan calendar/fasting records, and background azan service are not implemented yet. Validate prayer times with a local mosque before relying on them.
