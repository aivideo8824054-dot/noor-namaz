# Noor Namaz Updated Project
Dark green and gold starter app. Includes 20 dua entries, 12-hour display formatting, Hijri date display using Android/Chrome Intl calendar support, GPS permission flow, Android compass sensor bridge, and Noor Namaz launcher icon.
Prayer times are currently approximate demonstration calculations, not verified religious timetable data. Dua translations/wording require scholarly review. Qibla depends on device compass calibration and sensor availability. Test on a physical Android device.
