package com.noornamaz.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.content.Context;
import android.hardware.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity implements SensorEventListener {
    WebView web;
    SensorManager sm;
    Sensor accel, magnet;
    float[] gravity, geomagnetic;
    float azimuth = 0;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,42,32));
        getWindow().setNavigationBarColor(Color.rgb(7,42,32));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(7,42,32));
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setGeolocationEnabled(true);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED ||
                   checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED) callback.invoke(origin,true,false);
                else { requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},41); callback.invoke(origin,false,false); }
            }
        });
        web.addJavascriptInterface(new Object(){
            @JavascriptInterface public float getAzimuth(){ return azimuth; }
            @JavascriptInterface public boolean hasCompass(){ return sm!=null && sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)!=null; }
        },"AndroidCompass");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        sm=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
        if(sm!=null){ accel=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER); magnet=sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD); }
    }
    @Override protected void onResume(){ super.onResume(); if(sm!=null){ if(accel!=null)sm.registerListener(this,accel,SensorManager.SENSOR_DELAY_UI); if(magnet!=null)sm.registerListener(this,magnet,SensorManager.SENSOR_DELAY_UI);} }
    @Override protected void onPause(){ super.onPause(); if(sm!=null)sm.unregisterListener(this); }
    @Override public void onSensorChanged(SensorEvent e){
        if(e.sensor.getType()==Sensor.TYPE_ACCELEROMETER) gravity=e.values.clone();
        if(e.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD) geomagnetic=e.values.clone();
        if(gravity!=null && geomagnetic!=null){ float[] R=new float[9],I=new float[9]; if(SensorManager.getRotationMatrix(R,I,gravity,geomagnetic)){ float[] o=new float[3]; SensorManager.getOrientation(R,o); azimuth=(float)Math.toDegrees(o[0]); if(azimuth<0)azimuth+=360; } }
    }
    @Override public void onAccuracyChanged(Sensor s,int a){}
}
