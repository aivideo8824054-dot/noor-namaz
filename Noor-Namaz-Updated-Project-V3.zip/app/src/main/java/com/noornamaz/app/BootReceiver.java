package com.noornamaz.app;
import android.content.*;
import android.app.*;
import android.os.Build;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
   android.content.SharedPreferences p=c.getSharedPreferences("noor_alarms",0);
   AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
   String[] names={"fajr","dhuhr","asr","maghrib","isha"};
   for(String name:names){ long when=p.getLong(name,0L); if(when==0L) continue; while(when<=System.currentTimeMillis()) when+=86400000L;
     Intent a=new Intent(c,AzanReceiver.class); a.putExtra("name",name);
     PendingIntent pi=PendingIntent.getBroadcast(c,name.hashCode(),a,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
     if(Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms()){
       if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.setExact(AlarmManager.RTC_WAKEUP,when,pi);
     }
     p.edit().putLong(name,when).apply();
   }
 }
}
