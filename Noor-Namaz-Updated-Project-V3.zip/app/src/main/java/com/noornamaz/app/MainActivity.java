package com.noornamaz.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.location.Geocoder;
import java.util.Locale;
import java.util.List;
import android.webkit.*;

public class MainActivity extends Activity {
    WebView web;
    static final int PICK_AUDIO=44;
    GeolocationPermissions.Callback pendingGeo; String pendingOrigin;
    boolean alarmPermissionRequested=false;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF101010);
        getWindow().setNavigationBarColor(0xFF101010);
        web=new WebView(this); setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setGeolocationEnabled(true);
        web.addJavascriptInterface(new Bridge(), "AndroidAzan");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED) callback.invoke(origin,true,false);
                else { pendingGeo=callback; pendingOrigin=origin; requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},10); }
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        createChannel();
        if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9);
    }
    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel("azan","Azan alerts",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Noor Namaz prayer time alerts");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    class Bridge {
        @JavascriptInterface public void schedule(String name, long millis, boolean enabled) {
            Intent i=new Intent(MainActivity.this, AzanReceiver.class);
            i.putExtra("name",name);
            PendingIntent pi=PendingIntent.getBroadcast(MainActivity.this, name.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
            if(!enabled){ am.cancel(pi); getSharedPreferences("noor_alarms",0).edit().remove(name).apply(); return; }
            getSharedPreferences("noor_alarms",0).edit().putLong(name,millis).apply();
            if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){
                if(!alarmPermissionRequested){ alarmPermissionRequested=true; startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); }
                return;
            }
            if(millis<=System.currentTimeMillis()) millis += 24L*60*60*1000;
            if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);
            else am.setExact(AlarmManager.RTC_WAKEUP,millis,pi);
        }
        @JavascriptInterface public void chooseAudio(){ runOnUiThread(()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i,PICK_AUDIO);
        });}
        @JavascriptInterface public void setPlace(String state, String district, String city) {
            String query = city + ", " + district + ", " + state + ", India";
            try {
                Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
                if (Build.VERSION.SDK_INT >= 33) {
                    geocoder.getFromLocationName(query, 1, results -> {
                        if (results != null && !results.isEmpty()) {
                            android.location.Address a = results.get(0);
                            final double la=a.getLatitude(), lo=a.getLongitude();
                            runOnUiThread(() -> web.evaluateJavascript("setResolvedPlace(" + la + "," + lo + ")", null));
                        } else runOnUiThread(() -> web.evaluateJavascript("placeNotFound()", null));
                    });
                } else {
                    List<android.location.Address> results = geocoder.getFromLocationName(query, 1);
                    if (results != null && !results.isEmpty()) {
                        final double la=results.get(0).getLatitude(), lo=results.get(0).getLongitude();
                        runOnUiThread(() -> web.evaluateJavascript("setResolvedPlace(" + la + "," + lo + ")", null));
                    } else runOnUiThread(() -> web.evaluateJavascript("placeNotFound()", null));
                }
            } catch (Exception e) {
                runOnUiThread(() -> web.evaluateJavascript("placeNotFound()", null));
            }
        }
        @JavascriptInterface public void testAzan(){ runOnUiThread(()->{ Intent s=new Intent(MainActivity.this,AzanService.class); s.putExtra("name","Test"); if(Build.VERSION.SDK_INT>=26) startForegroundService(s); else startService(s); }); }
        @JavascriptInterface public void stopAzan(){ stopService(new Intent(MainActivity.this,AzanService.class)); }
    }
    @Override protected void onResume(){
        super.onResume();
        if(web!=null) web.postDelayed(()->web.evaluateJavascript("if(window.syncNativeAzan) syncNativeAzan();",null),500);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==10 && pendingGeo!=null){ boolean ok=false; for(int g:grantResults) if(g==PackageManager.PERMISSION_GRANTED) ok=true; pendingGeo.invoke(pendingOrigin,ok,false); pendingGeo=null; }
    }
    @Override protected void onActivityResult(int r,int c,@Nullable Intent d){
        super.onActivityResult(r,c,d);
        if(r==PICK_AUDIO && c==RESULT_OK && d!=null && d.getData()!=null){
            Uri u=d.getData(); getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getSharedPreferences("noor",0).edit().putString("azan_uri",u.toString()).apply();
            web.evaluateJavascript("audioChosen()",null);
        }
    }
}
