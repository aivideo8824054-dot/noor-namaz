# Noor Namaz — V3 project

This build keeps the original dark-green/gold prayer-time interface and uses the 20 duas from the latest supplied project, followed by 20 additional daily duas (40 displayed entries total). It connects Android exact-alarm scheduling, notification channel, custom audio document picker, reboot restoration, and WebView location permission handling.

Important: prayer calculations are still estimates and must be compared with a trusted local mosque timetable. The app's compass and all phone-specific background behavior require testing on the target device. Android may require the user to allow notifications and exact alarms; battery restrictions can also affect alarms. The daily repeat uses the previous local alarm time until the app refreshes the calculated prayer times.

Build with `gradle :app:assembleDebug` using Java 17 and Android SDK 35.
