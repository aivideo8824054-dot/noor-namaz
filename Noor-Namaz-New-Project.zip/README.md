# Noor Namaz Android App

A fresh Android WebView starter project for the Noor Namaz app.

## Build
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- Build task: `:app:assembleDebug`

This is the first starter version. Prayer times currently shown on Home are sample placeholders, not verified prayer times. Location-based prayer calculation, reliable background azan scheduling, full language support, compass sensors, verified dua references, zakat and Ramadan calculators will be implemented and tested in later steps.

## GitHub Actions
The workflow in `.github/workflows/android.yml` builds a debug APK and uploads it as an artifact.
